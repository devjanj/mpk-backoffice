import { Client } from 'ssh2';
import * as fs from 'fs';

const conn = new Client();

const host = '209.38.167.154';
const username = 'root';
const password = 'janeKjaneK12.';

conn.on('ready', () => {
    console.log('SSH Ready. Executing Setup Commands...');

    const copyEnv = () => {
        return new Promise((resolve, reject) => {
            conn.sftp((err, sftp) => {
                if (err) return reject(err);
                const localEnv = '/Users/janjagodnik/Documents/GitHub/mpk-backoffice/.env.local';
                const remoteEnv = '/root/mpk-backoffice/.env.local';
                sftp.fastPut(localEnv, remoteEnv, (err) => {
                    if (err) {
                        console.error('Failed to copy .env.local to droplet', err);
                        resolve(false);
                    } else {
                        console.log('Successfully copied .env.local');
                        resolve(true);
                    }
                });
            });
        });
    }

    const runCommand = (cmd: string) => {
        return new Promise((resolve) => {
            console.log(`\n--- Running: ${cmd} ---`);
            conn.exec(cmd, (err, stream) => {
                if (err) throw err;
                stream.on('close', (code: any) => {
                    resolve(code);
                }).on('data', (data: any) => {
                    process.stdout.write(data);
                }).stderr.on('data', (data: any) => {
                    process.stderr.write(data);
                });
            });
        });
    }

    // Main Orchestrator
    const runAll = async () => {
        await runCommand('apt update && apt install -y git curl');
        await runCommand('curl -fsSL https://deb.nodesource.com/setup_22.x | bash -');
        await runCommand('apt install -y nodejs');
        await runCommand('npm install -g pm2 tsx');

        await runCommand('git clone https://github.com/JanJagodnik/mpk-backoffice.git /root/mpk-backoffice || (cd /root/mpk-backoffice && git fetch && git reset --hard origin/main)');

        await copyEnv();

        await runCommand('cd /root/mpk-backoffice && npm install');
        await runCommand('ufw allow 3001 && systemctl restart ufw || true');
        await runCommand('pm2 delete mpk-api || true');
        await runCommand('cd /root/mpk-backoffice && pm2 start "npx tsx server.ts" --name mpk-api');
        await runCommand('pm2 save');
        await runCommand('pm2 status');

        console.log("Configuration Complete!");
        conn.end();
    }

    runAll();

}).connect({
    host: host,
    port: 22,
    username: username,
    password: password
});
